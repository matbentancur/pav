#ifndef TURNO_H
#define TURNO_H

#include <iostream>

using namespace std;

enum Turno {
    Manana = 1,
    Tarde = 2,
    Noche = 3
};

#endif // TURNO_H
